
CREATE DATABASE RaceDayDB;

-- =========================================
-- ORGANISER TABLE
-- =========================================
CREATE TABLE Organiser (
    Organiser_ID INT IDENTITY(1,1) PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT GETDATE()
);

-- =========================================
-- EVENTS TABLE
-- =========================================
CREATE TABLE Events (
    Event_ID INT IDENTITY(1,1) PRIMARY KEY,
    Organiser_ID INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    event_date DATE NOT NULL,
    location VARCHAR(150) NOT NULL,
    description VARCHAR(MAX),
    created_at DATETIME DEFAULT GETDATE(),

    CONSTRAINT FK_Events_Organiser
        FOREIGN KEY (Organiser_ID)
        REFERENCES Organiser(Organiser_ID)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);
GO

-- =========================================
-- CATEGORY TABLE
-- =========================================
CREATE TABLE Category (
    Category_ID INT IDENTITY(1,1) PRIMARY KEY,
    Event_ID INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    distance_km DECIMAL(6,2) NOT NULL,
    max_participants INT NOT NULL,

    CONSTRAINT FK_Category_Event
        FOREIGN KEY (Event_ID)
        REFERENCES Events(Event_ID)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);


-- =========================================
-- PARTICIPANT TABLE
-- =========================================
CREATE TABLE Participant (
    Participant_ID INT IDENTITY(1,1) PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(20),
    created_at DATETIME DEFAULT GETDATE()
);


-- =========================================
-- ENROLMENT TABLE
-- =========================================
CREATE TABLE Enrolment (
    Enrolment_ID INT IDENTITY(1,1) PRIMARY KEY,
    Category_ID INT NOT NULL,
    Participant_ID INT NOT NULL,
    enrolled_at DATETIME DEFAULT GETDATE(),
    status VARCHAR(30) DEFAULT 'Enrolled',

    CONSTRAINT FK_Enrolment_Category
        FOREIGN KEY (Category_ID)
        REFERENCES Category(Category_ID)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT FK_Enrolment_Participant
        FOREIGN KEY (Participant_ID)
        REFERENCES Participant(Participant_ID)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);


---- =========================================
---- RESULT TABLE
---- =========================================
CREATE TABLE Result (
    Result_ID INT IDENTITY(1,1) PRIMARY KEY,
    Enrolment_ID INT NOT NULL,
    Organiser_ID INT NOT NULL,
    finish_time TIME,
    position INT,
    captured_at DATETIME DEFAULT GETDATE(),

    CONSTRAINT FK_Result_Enrolment
        FOREIGN KEY (Enrolment_ID)
        REFERENCES Enrolment(Enrolment_ID)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT FK_Result_Organiser
        FOREIGN KEY (Organiser_ID)
        REFERENCES Organiser(Organiser_ID)
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);



---- =========================================
----. POPULATE ORGANISER TABLE
---- =========================================
INSERT INTO Organiser
    (first_name, last_name, email, password_hash)
VALUES
    ('John', 'Mokoena', 'john.mokoena@raceday.co.za', 'hash_john_123'),
    ('Sarah', 'Naidoo', 'sarah.naidoo@raceday.co.za', 'hash_sarah_123'),
    ('David', 'Smith', 'david.smith@raceday.co.za', 'hash_david_123'),
    ('Lerato', 'Molefe', 'lerato.molefe@raceday.co.za', 'hash_lerato_123'),
    ('Michael', 'Dlamini', 'michael.dlamini@raceday.co.za', 'hash_michael_123');


-- =========================================
--. POPULATE EVENTS TABLE
-- Organiser_ID 1-5 come from the records above
-- =========================================
INSERT INTO Events
    (Organiser_ID, name, event_date, location, description)
VALUES
    (1, 'Johannesburg City Run', '2026-10-10',
     'Johannesburg, Gauteng',
     'Annual city running event for beginners and experienced runners.'),

    (2, 'Cape Town Marathon', '2026-10-25',
     'Cape Town, Western Cape',
     'Long-distance marathon through Cape Town.'),

    (3, 'Pretoria Spring Run', '2026-09-20',
     'Pretoria, Gauteng',
     'Spring running event suitable for families and athletes.'),

    (4, 'Durban Beach Run', '2026-11-07',
     'Durban, KwaZulu-Natal',
     'Beachside running event along the Durban coastline.'),

    (5, 'Soweto Community Race', '2026-12-05',
     'Soweto, Gauteng',
     'Community-focused race promoting health and fitness.');



-- =========================================
-- POPULATE CATEGORY TABLE
-- Each event gets multiple race categories
-- =========================================
INSERT INTO Category
    (Event_ID, name, distance_km, max_participants)
VALUES
    -- Johannesburg City Run
    (1, '5 KM Fun Run', 5.00, 500),
    (1, '10 KM Race', 10.00, 750),
    (1, '21 KM Half Marathon', 21.10, 1000),

    -- Cape Town Marathon
    (2, '10 KM Race', 10.00, 800),
    (2, '21 KM Half Marathon', 21.10, 1500),
    (2, '42 KM Marathon', 42.20, 2000),

    -- Pretoria Spring Run
    (3, '5 KM Fun Run', 5.00, 400),
    (3, '10 KM Race', 10.00, 600),

    -- Durban Beach Run
    (4, '5 KM Beach Run', 5.00, 500),
    (4, '10 KM Beach Race', 10.00, 750),

    -- Soweto Community Race
    (5, '5 KM Community Run', 5.00, 600),
    (5, '10 KM Community Race', 10.00, 800);


-- =========================================
--. POPULATE PARTICIPANT TABLE
-- =========================================
INSERT INTO Participant
    (first_name, last_name, email, password_hash, date_of_birth, gender)
VALUES
    ('Thabo', 'Nkosi', 'thabo.nkosi@email.com',
     'hash_thabo_123', '1998-04-15', 'Male'),

    ('Nomsa', 'Khumalo', 'nomsa.khumalo@email.com',
     'hash_nomsa_123', '2000-08-22', 'Female'),

    ('Sipho', 'Zulu', 'sipho.zulu@email.com',
     'hash_sipho_123', '1995-11-03', 'Male'),

    ('Ayanda', 'Mthembu', 'ayanda.mthembu@email.com',
     'hash_ayanda_123', '2002-02-18', 'Female'),

    ('Kabelo', 'Molefe', 'kabelo.molefe@email.com',
     'hash_kabelo_123', '1997-06-30', 'Male'),

    ('Lindiwe', 'Dube', 'lindiwe.dube@email.com',
     'hash_lindiwe_123', '1999-09-12', 'Female'),

    ('Musa', 'Ndlovu', 'musa.ndlovu@email.com',
     'hash_musa_123', '1994-01-25', 'Male'),

    ('Zanele', 'Mkhize', 'zanele.mkhize@email.com',
     'hash_zanele_123', '2001-05-10', 'Female');


-- =========================================
--  POPULATE ENROLMENT TABLE
-- Category_IDs come from the Category records above
-- Participant_IDs come from the Participant records above
-- =========================================
INSERT INTO Enrolment
    (Category_ID, Participant_ID, status)
VALUES
    (1, 1, 'Enrolled'),
    (1, 2, 'Enrolled'),
    (2, 3, 'Enrolled'),
    (2, 4, 'Enrolled'),
    (3, 5, 'Enrolled'),
    (4, 6, 'Enrolled'),
    (5, 7, 'Enrolled'),
    (6, 8, 'Enrolled'),
    (7, 1, 'Enrolled'),
    (8, 2, 'Enrolled'),
    (9, 3, 'Enrolled'),
    (10, 4, 'Enrolled');



 --=========================================
 -- POPULATE RESULT TABLE
 --Enrolment_IDs 1-12 come from Enrolment above
 --Organiser_IDs 1-5 come from Organiser above
 --=========================================
INSERT INTO Result
    (Enrolment_ID, Organiser_ID, finish_time, position)
VALUES
    (1, 1, '00:28:35', 1),
    (2, 1, '00:31:42', 2),
    (3, 3, '00:54:18', 1),
    (4, 3, '00:58:27', 2),
    (5, 2, '01:48:35', 1),
    (6, 2, '00:52:14', 1),
    (7, 4, '00:25:48', 1),
    (8, 4, '00:27:31', 2),
    (9, 5, '00:29:56', 1),
    (10, 5, '00:34:12', 2),
    (11, 4, '00:28:44', 1),
    (12, 4, '00:32:19', 2);
GO


-- =========================================
-- 7. CHECK ALL TABLES
-- =========================================

SELECT * FROM Organiser;
SELECT * FROM Events;
SELECT * FROM Category;
SELECT * FROM Participant;
SELECT * FROM Enrolment;
SELECT * FROM Result;
